package com.example.aquashdw.emptyroomfinder;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by aquashdw on 18. 5. 17.
 */

public class TimetableEditActivity extends Activity {


    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.timetable_edit_layout);
    }
}
