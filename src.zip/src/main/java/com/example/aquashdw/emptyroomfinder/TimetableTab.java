package com.example.aquashdw.emptyroomfinder;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;

/**
 * Created by aquashdw on 18. 5. 14.
 */

public class TimetableTab extends Fragment{

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View thisView = inflater.inflate(R.layout.timetable_layout, container, false);

        Button editButton = thisView.findViewById(R.id.editButton);
        Button delButton = thisView.findViewById(R.id.delButton);

        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Method to create intent for edit timetable
                Toast.makeText(getContext().getApplicationContext(), "edit hit", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getActivity(), TimetableEditActivity.class);
                startActivity(intent);
            }
        });

        delButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Method to reset timetable + warning message
                Toast.makeText(getContext().getApplicationContext(), "delete hit", Toast.LENGTH_SHORT).show();
            }
        });

        GridView gridView = thisView.findViewById(R.id.tableGrid);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(thisView.getContext(), ""+i,Toast.LENGTH_SHORT).show();
            }
        });


        TimeAdapter timeAdapter = new TimeAdapter(thisView.getContext());
        gridView.setAdapter(timeAdapter);

        return thisView;
    }


}
