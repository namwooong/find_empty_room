package com.example.aquashdw.emptyroomfinder;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by aquashdw on 18. 5. 17.
 */

public class TimetableEditActivity extends Activity {



    @Override
    public void onCreate(final Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.timetable_edit_layout);

        final LinearLayout timeTableResults = findViewById(R.id.timetable_result);
        timeTableResults.setOrientation(LinearLayout.VERTICAL);

        GridView gridView = findViewById(R.id.tableGrid);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(getApplicationContext(), ""+i,Toast.LENGTH_SHORT).show();
                TextView testText = new TextView(getApplicationContext());
                String testString = getResources().getString(R.string.test);
                testString += " ";
                testString += i;
                testText.setText(testString);

                timeTableResults.addView(testText, timeTableResults.getChildCount());
            }
        });


        TimeAdapter timeAdapter = new TimeAdapter(getApplicationContext());
        gridView.setAdapter(timeAdapter);

        Spinner daySpin = findViewById(R.id.day_spin_);
        Spinner buildSpin = findViewById(R.id.build_spin_);

        ArrayAdapter<CharSequence> dayAdapt = ArrayAdapter.createFromResource(
                getApplicationContext(),R.array.day_spin_ini, android.R.layout.simple_spinner_dropdown_item);
        ArrayAdapter<CharSequence> buildAdapt = ArrayAdapter.createFromResource(
                getApplicationContext(),R.array.build_spin, android.R.layout.simple_spinner_dropdown_item);

        daySpin.setAdapter(dayAdapt);
        buildSpin.setAdapter(buildAdapt);
    }
}
