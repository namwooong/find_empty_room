package com.example.aquashdw.emptyroomfinder;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by aquashdw on 18. 5. 24.
 */

public class TimeAdapter extends BaseAdapter {
    private final Context context;
    private final List<Item> items = new ArrayList<>();

    private final LayoutInflater inflater;

    public TimeAdapter(Context context){


        for(int i = 0; i < 50; i++){
            items.add(new Item(""));
        }

        this.context = context;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount(){
        return items.size();
    }

    @Override
    public long getItemId(int position){
        return 0;
    }

    @Override
    public Item getItem(int position){
        return items.get(position);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        View view = convertView;

        // get item in position
        Item item = getItem(position);

        if(view == null){
            view = inflater.inflate(R.layout.time_item, parent, false);
        }

        /**
        // if no lectures on the position, fill with blank/bound
        if(item.getFill()){
            view = new TimeImageView(view.getContext());
        }
        else{
            TextView dummy = new TextView(context);
            dummy.setText(R.string.day_mon);
            view = dummy;
        }
        */


        return view;
    }

    public static class Item{
        public final String data;
        private final int color;
        private final boolean fill;

        private TimeImageView dataToShow;


        public Item(String inputString){
            this.data = inputString;
            this.color = -1;
            this.fill = false;
        }

        public Item(String inputString, int i){
            this.data = inputString;
            this.color = i;
            this.fill = true;
            this.setData();
        }

        private void setData() {
            // parse string data to fill TimeImageView
        }

        public boolean getFill(){
            return fill;
        }

        public String getString(){
            return data;
        }
    }
}
