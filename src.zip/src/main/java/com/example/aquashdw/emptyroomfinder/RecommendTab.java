package com.example.aquashdw.emptyroomfinder;

import android.content.Intent;
import android.icu.util.Calendar;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by aquashdw on 18. 5. 14.
 */

public class RecommendTab extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedinstanceState){
        final View thisView = inflater.inflate(R.layout.recommend_layout,container,false);

        Button recomButton = thisView.findViewById(R.id.recommendButton);

        recomButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Method to set data input based on user timetable

                // Method to move to SearchResultActivity

                Intent intent = new Intent(getActivity(), SearchResultActivity.class);

                startActivity(intent);

                Toast.makeText(getContext().getApplicationContext(), "recommend hit", Toast.LENGTH_SHORT).show();
            }
        });

        Calendar calendar = Calendar.getInstance();
        int currentDayInt = calendar.get(Calendar.DAY_OF_WEEK);
        long currentTimeLong = System.currentTimeMillis();

        String currentDayTime = "";
        currentDayTime += currentDayInt+" ";
        currentDayTime += currentTimeLong;

        TextView textView = thisView.findViewById(R.id.current_time_rec);

        textView.setText(currentDayTime);


        return thisView;
    }
}
