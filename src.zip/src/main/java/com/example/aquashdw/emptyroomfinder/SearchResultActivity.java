package com.example.aquashdw.emptyroomfinder;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by aquashdw on 18. 5. 23.
 */

public class SearchResultActivity extends AppCompatActivity {

    ArrayList<String> resultStrings = new ArrayList<>();
    String searchQuery;

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.result_layout);

        Bundle extras = getIntent().getExtras();
        if(extras != null){
            searchQuery = extras.getString("QUERY");
            TextView textView = (TextView) findViewById(R.id.result_test);
            textView.setText(searchQuery);
            // method to search thru database
        }

        if(resultStrings != null){
            // method to display results
        }

        Button backButton = (Button)findViewById(R.id.back_button);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
